const wv = window.chrome?.webview;

// ============ UTILITY FUNCTIONS ============

function showToast(message, type = 'info', duration = 3000) {
  const container = document.getElementById('toastContainer');
  const toast = document.createElement('div');
  toast.className = `toast ${type}`;
  toast.innerHTML = `
    <div class="flex items-start gap-3">
      <div class="text-xl">
        ${type === 'success' ? '✅' : type === 'error' ? '❌' : 'ℹ️'}
      </div>
      <div class="flex-1">
        <div class="font-medium text-white">${message}</div>
      </div>
      <button onclick="this.parentElement.parentElement.remove()" class="text-gray-400 hover:text-white">
        ✕
      </button>
    </div>
  `;
  container.appendChild(toast);

  setTimeout(() => {
    toast.style.opacity = '0';
    toast.style.transform = 'translateX(100px)';
    setTimeout(() => toast.remove(), 300);
  }, duration);
}

function updateStatus(message) {
  document.getElementById('statusText').textContent = message;
}

// ============ EVENT HANDLERS ============

document.getElementById('btnRefresh').addEventListener('click', () => {
  wv?.postMessage({ type: 'refresh' });
  showToast('Scan des fenêtres en cours...', 'info', 2000);
});

document.getElementById('btnSaveCfg').addEventListener('click', () => {
  showConfigModal();
});

document.getElementById('btnDefineHotkey')?.addEventListener('click', () => {
  showHotkeyModal();
});

// Event delegation for window cards
document.getElementById('windowsGrid').addEventListener('click', (ev) => {
  // Focus button
  const focusBtn = ev.target.closest('[data-action="focus"]');
  if (focusBtn) {
    const id = focusBtn.dataset.id;
    wv?.postMessage({ type: 'focus', id });
    showToast('Fenêtre mise au premier plan', 'success', 2000);
    return;
  }

  // Move up button
  const upBtn = ev.target.closest('[data-action="move-up"]');
  if (upBtn) {
    wv?.postMessage({ type: 'move', id: upBtn.dataset.id, dir: -1 });
    return;
  }

  // Move down button
  const downBtn = ev.target.closest('[data-action="move-down"]');
  if (downBtn) {
    wv?.postMessage({ type: 'move', id: downBtn.dataset.id, dir: 1 });
    return;
  }

  // Toggle switch
  const toggle = ev.target.closest('.toggle');
  if (toggle) {
    const id = toggle.dataset.id;
    const isActive = toggle.classList.contains('active');
    const newValue = !isActive;

    toggle.classList.toggle('active', newValue);
    wv?.postMessage({ type: 'toggle', id, value: newValue });
  }
});

// Config list event delegation
document.getElementById('configList').addEventListener('click', (ev) => {
  const loadBtn = ev.target.closest('[data-action="load-config"]');
  if (loadBtn) {
    const name = loadBtn.dataset.name;
    wv?.postMessage({ type: 'loadConfig', name });
    showToast(`Configuration "${name}" chargée`, 'success');
    return;
  }

  const deleteBtn = ev.target.closest('[data-action="delete-config"]');
  if (deleteBtn) {
    const name = deleteBtn.dataset.name;
    if (confirm(`Supprimer la configuration "${name}" ?`)) {
      wv?.postMessage({ type: 'deleteConfig', name });
      showToast(`Configuration "${name}" supprimée`, 'info');
    }
    return;
  }
});

// ============ RENDERING FUNCTIONS ============

window.renderEntries = (data) => {
  try {
    console.log('renderEntries called with:', data);
    console.log('entries:', data.entries);
    console.log('First entry:', data.entries?.[0]);

    // Log all property names to check casing
    if (data.entries?.[0]) {
      console.log('First entry keys:', Object.keys(data.entries[0]));
    }

    const { entries, activeConfig, savedConfigs, stats, hotkeyNext, hotkeyPrev } = data;

  // Update hotkeys
  document.getElementById('hotkeyNext').textContent = hotkeyNext || '-';
  document.getElementById('hotkeyPrev').textContent = hotkeyPrev || '-';

  // Update mouse buttons (will be added in data later)
  document.getElementById('mouseNext').textContent = data.mouseNext || '-';
  document.getElementById('mousePrev').textContent = data.mousePrev || '-';

  // Render config list
  const configList = document.getElementById('configList');
  if (savedConfigs && savedConfigs.length > 0) {
    configList.innerHTML = savedConfigs.map(name => {
      const isActive = name === activeConfig;
      return `
        <div class="flex items-center gap-2 p-2 rounded ${isActive ? 'bg-blue-500/20 border border-blue-500/30' : 'bg-gray-800/30 hover:bg-gray-800/50'} transition-colors">
          <button
            data-action="load-config"
            data-name="${name}"
            class="flex-1 text-left text-sm ${isActive ? 'text-blue-400 font-medium' : 'text-gray-300'}"
          >
            ${isActive ? '✓ ' : ''}${name}
          </button>
          <button
            data-action="delete-config"
            data-name="${name}"
            class="btn-ghost btn-icon text-xs hover:text-red-400"
            title="Supprimer"
          >
            🗑️
          </button>
        </div>
      `;
    }).join('');
  } else {
    configList.innerHTML = '<div class="text-xs text-gray-500 text-center py-4">Aucune configuration sauvegardée</div>';
  }

  // Render window cards
  const grid = document.getElementById('windowsGrid');
  const emptyState = document.getElementById('emptyState');

  console.log('📊 Rendering entries:', entries?.length || 0);
  console.log('📊 Stats:', stats);

  if (!entries || entries.length === 0) {
    console.warn('⚠️ No entries to display');
    if (grid) grid.style.display = 'none';
    if (emptyState) emptyState.style.display = 'block';
    updateStatus('Aucune fenêtre détectée');
    return;
  }

  console.log('✅ Will render', entries.length, 'entries');

  if (emptyState) emptyState.style.display = 'none';
  if (grid) grid.style.display = 'block';

  // Calculate cycle order for active windows
  const activeEntriesForCycle = entries.filter(e => e.isSelected);
  const cycleOrderMap = new Map();
  activeEntriesForCycle.forEach((e, idx) => {
    cycleOrderMap.set(e.id, idx + 1);
  });

  console.log('Active entries for cycle:', activeEntriesForCycle.length);

  try {
    grid.innerHTML = entries.map((e, index) => {
      const label = (e.windowTitleHint && e.windowTitleHint.trim()) ? e.windowTitleHint : e.name;
      const isFirst = index === 0;
      const isLast = index === entries.length - 1;
      const cycleOrder = cycleOrderMap.get(e.id);

      return `
        <div class="window-card ${e.isSelected ? '' : 'inactive'} rounded-xl p-4 animate-slide-in relative" style="animation-delay: ${index * 0.05}s">
          <!-- Cycle order badge -->
          ${e.isSelected && cycleOrder ? `<div class="cycle-badge">${cycleOrder}</div>` : ''}

          <!-- App Icon -->
          <div class="app-icon">
            ${e.iconBase64
              ? `<img src="data:image/png;base64,${e.iconBase64}" alt="${e.name}" />`
              : '🎮'}
          </div>

          <!-- Main Content -->
          <div class="flex-1 min-w-0">
            <div class="flex items-center gap-2 mb-1">
              <h3 class="font-semibold text-white truncate text-lg" title="${label}">
                ${label}
              </h3>
            </div>
            <div class="flex items-center gap-4 text-xs text-gray-400">
              ${e.windowTitleHint && e.windowTitleHint !== label ? `<span>${e.name}</span>` : ''}
              <span>PID: ${e.pid}</span>
            </div>
          </div>

          <!-- Toggle -->
          <div
            class="toggle ${e.isSelected ? 'active' : ''}"
            data-id="${e.id}"
            title="${e.isSelected ? 'Désactiver du cycle' : 'Activer dans le cycle'}"
          ></div>

          <!-- Actions -->
          <div class="flex items-center gap-2">
            <button
              data-action="focus"
              data-id="${e.id}"
              class="btn btn-primary text-sm"
              title="Mettre au premier plan"
            >
              <span>Afficher</span>
            </button>

            <button
              data-action="move-up"
              data-id="${e.id}"
              class="btn btn-secondary btn-icon"
              title="Monter dans la liste"
              ${isFirst ? 'disabled style="opacity: 0.3; cursor: not-allowed;"' : ''}
            >
              ↑
            </button>

            <button
              data-action="move-down"
              data-id="${e.id}"
              class="btn btn-secondary btn-icon"
              title="Descendre dans la liste"
              ${isLast ? 'disabled style="opacity: 0.3; cursor: not-allowed;"' : ''}
            >
              ↓
            </button>
          </div>
        </div>
      `;
    }).join('');

    console.log('Grid rendered successfully');
  } catch (err) {
    console.error('Error rendering grid:', err);
    if (grid) {
      grid.innerHTML = '<div class="text-center text-red-400 p-8">Erreur lors du rendu des fenêtres</div>';
    }
  }

    updateStatus(`${stats?.visible ?? 0} fenêtre(s) active(s) sur ${stats?.total ?? 0} suivie(s)`);
  } catch (err) {
    console.error('❌ Error in renderEntries:', err);
    console.error('Stack:', err.stack);
    showToast('Erreur lors du rendu: ' + err.message, 'error', 5000);
  }
};

// Status and hotkey label setters
window.setStatus = (msg) => {
  updateStatus(msg);
  showToast(msg, 'info', 3000);
};

window.setHotkeyLabel = (text) => {
  // Cette fonction n'est plus vraiment nécessaire car on gère via renderEntries
  // Mais on la garde pour compatibilité avec le code C#
  console.log('Hotkey label:', text);
};

// ============ MODAL MANAGEMENT ============

function showModal(modalId) {
  const overlay = document.getElementById('modalOverlay');
  const modal = document.getElementById(modalId);
  overlay.style.display = 'flex';
  modal.style.display = 'block';
}

function hideModal(modalId) {
  const overlay = document.getElementById('modalOverlay');
  const modal = document.getElementById(modalId);
  modal.style.display = 'none';
  overlay.style.display = 'none';
}

// Hotkey Modal
function showHotkeyModal() {
  showModal('hotkeyModal');
  document.getElementById('hotkeyDisplay').textContent = 'En attente...';

  // Listen for keydown
  const keyHandler = (e) => {
    e.preventDefault();

    // Cancel on Escape
    if (e.key === 'Escape') {
      document.removeEventListener('keydown', keyHandler);
      hideModal('hotkeyModal');
      return;
    }

    // Ignore modifier keys alone
    if (['Control', 'Alt', 'Shift', 'Meta'].includes(e.key)) {
      return;
    }

    // Check for modifiers
    const mods = [];
    if (e.ctrlKey) mods.push('Ctrl');
    if (e.altKey) mods.push('Alt');
    if (e.shiftKey) mods.push('Shift');
    if (e.metaKey) mods.push('Win');

    if (mods.length === 0) {
      document.getElementById('hotkeyDisplay').textContent = 'Ajoute au moins un modifieur (Ctrl/Alt/Shift/Win)';
      return;
    }

    const keyName = e.key.length === 1 ? e.key.toUpperCase() : e.key;
    const combo = [...mods, keyName].join(' + ');

    document.getElementById('hotkeyDisplay').textContent = combo;

    // Send to backend
    setTimeout(() => {
      wv?.postMessage({
        type: 'setHotkey',
        key: e.keyCode || e.which,
        ctrl: e.ctrlKey,
        alt: e.altKey,
        shift: e.shiftKey,
        win: e.metaKey
      });
      document.removeEventListener('keydown', keyHandler);
      hideModal('hotkeyModal');
      showToast(`Raccourci défini: ${combo}`, 'success');
    }, 500);
  };

  document.addEventListener('keydown', keyHandler);
}

// Config Modal
function showConfigModal() {
  showModal('configModal');
  const input = document.getElementById('configNameInput');
  input.value = '';
  input.focus();
}

document.getElementById('configModalCancel')?.addEventListener('click', () => {
  hideModal('configModal');
});

document.getElementById('configModalSave')?.addEventListener('click', () => {
  const name = document.getElementById('configNameInput').value.trim();
  if (!name) {
    showToast('Le nom ne peut pas être vide', 'error');
    return;
  }

  wv?.postMessage({ type: 'saveConfig', name });
  hideModal('configModal');
  showToast(`Configuration "${name}" sauvegardée`, 'success');
});

// Enter key to save
document.getElementById('configNameInput')?.addEventListener('keydown', (e) => {
  if (e.key === 'Enter') {
    document.getElementById('configModalSave')?.click();
  } else if (e.key === 'Escape') {
    hideModal('configModal');
  }
});

// Click outside to close
document.getElementById('modalOverlay')?.addEventListener('click', (e) => {
  if (e.target.id === 'modalOverlay') {
    hideModal('hotkeyModal');
    hideModal('configModal');
    hideModal('mouseModal');
  }
});

// Mouse Button Modal
let currentMouseAction = null; // 'next' or 'prev'

function showMouseModal(action) {
  currentMouseAction = action;
  showModal('mouseModal');
  document.getElementById('mouseDisplay').textContent = 'En attente...';

  const instruction = action === 'next'
    ? 'Clique sur un bouton pour SUIVANT (X1 ou X2)'
    : 'Clique sur un bouton pour PRÉCÉDENT (X1 ou X2)';
  document.getElementById('mouseModalInstruction').textContent = instruction;

  // Mouse handler
  const mouseHandler = (e) => {
    e.preventDefault();

    // X1 button (usually back button) = button 3
    // X2 button (usually forward button) = button 4
    if (e.button === 3 || e.button === 4) {
      const btnNum = e.button === 3 ? 1 : 2;
      const btnName = e.button === 3 ? 'X1' : 'X2';

      document.getElementById('mouseDisplay').textContent = btnName;

      setTimeout(() => {
        wv?.postMessage({
          type: 'setMouseButton',
          action: currentMouseAction,
          button: btnNum
        });
        document.removeEventListener('mousedown', mouseHandler);
        document.removeEventListener('contextmenu', contextHandler);
        document.removeEventListener('keydown', keyHandler);
        hideModal('mouseModal');
        showToast(`Bouton souris ${btnName} défini pour ${currentMouseAction === 'next' ? 'suivant' : 'précédent'}`, 'success');
      }, 500);

      return false;
    }

    // Right-click to clear
    if (e.button === 2) {
      wv?.postMessage({
        type: 'setMouseButton',
        action: currentMouseAction,
        button: 0 // 0 = clear
      });
      document.removeEventListener('mousedown', mouseHandler);
      document.removeEventListener('contextmenu', contextHandler);
      document.removeEventListener('keydown', keyHandler);
      hideModal('mouseModal');
      showToast(`Bouton souris effacé pour ${currentMouseAction === 'next' ? 'suivant' : 'précédent'}`, 'info');
      return false;
    }
  };

  const contextHandler = (e) => {
    e.preventDefault();
    return false;
  };

  const keyHandler = (e) => {
    if (e.key === 'Escape') {
      document.removeEventListener('mousedown', mouseHandler);
      document.removeEventListener('contextmenu', contextHandler);
      document.removeEventListener('keydown', keyHandler);
      hideModal('mouseModal');
    }
  };

  document.addEventListener('mousedown', mouseHandler);
  document.addEventListener('contextmenu', contextHandler);
  document.addEventListener('keydown', keyHandler);
}

document.getElementById('btnDefineMouseNext')?.addEventListener('click', () => {
  showMouseModal('next');
});

document.getElementById('btnDefineMousePrev')?.addEventListener('click', () => {
  showMouseModal('prev');
});

// ============ EXTERNAL LINKS ============

// Handle external links (open in default browser)
document.addEventListener('DOMContentLoaded', () => {
  document.querySelectorAll('.footer-link').forEach(link => {
    link.addEventListener('click', (e) => {
      e.preventDefault();
      const url = link.getAttribute('href');

      // Send message to C# to open URL in default browser
      wv?.postMessage({
        type: 'openUrl',
        url: url
      });
    });
  });
});

// ============ INITIALIZATION ============

// Initial UI state
updateStatus('Prêt. Cliquez sur "Rafraîchir" pour scanner les fenêtres.');

console.log('DofusSwitcherWin UI loaded successfully ✨');
