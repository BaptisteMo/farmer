# 🎮 DofusSwitcher

**Gestionnaire de fenêtres ultra-moderne pour jouer à Dofus en multi-compte**

![Version](https://img.shields.io/badge/version-1.0.0-blue)
![Platform](https://img.shields.io/badge/platform-Windows%2010%2F11-blue)
![License](https://img.shields.io/badge/license-MIT-green)

DofusSwitcher est un outil gratuit et open-source qui facilite la gestion de plusieurs fenêtres Dofus simultanément. Avec une interface moderne et intuitive, naviguez entre vos personnages en un clic ou avec des raccourcis personnalisables.

---

## ✨ Fonctionnalités

### 🪟 Gestion Intelligente des Fenêtres
- **Détection automatique** de toutes vos fenêtres Dofus ouvertes
- **Affichage avec icônes** pour identifier rapidement chaque fenêtre
- **Ordre de cycle personnalisable** : organisez vos personnages comme vous le souhaitez
- **Activation/désactivation** individuelle de chaque fenêtre

### ⌨️ Raccourcis Clavier
- **Raccourci personnalisable** pour cycler entre vos fenêtres
- Compatible avec les modificateurs : Ctrl, Alt, Shift, Win
- Configuration via une **modale moderne** (fini les boîtes de dialogue Windows)
- Fallback automatique si le raccourci est réservé par Windows

### 🖱️ Boutons Souris
- **Configuration des boutons X1 et X2** de votre souris
- Définissez séparément les boutons pour "Suivant" et "Précédent"
- Navigation ultra-rapide sans quitter votre clavier des mains

### 💾 Sauvegarde de Configurations
- **Sauvegardez vos setups** : PvM, Kolizeum, Farm, etc.
- **Chargement instantané** de vos configurations
- **Plusieurs configs** pour différentes situations de jeu
- Indicateur visuel de la configuration active

### 🎨 Interface Moderne
- Design moderne avec **Tailwind CSS**
- **Thème sombre** adapté aux longues sessions de jeu
- **Animations fluides** et transitions agréables
- **Responsive** : s'adapte à la taille de votre fenêtre
- **Notifications toast** pour tous les événements

---

## 📥 Installation

### Configuration Requise
- **Windows 10 ou 11** (64-bit)
- **~80 MB** d'espace disque
- **WebView2 Runtime** (installé automatiquement si nécessaire)

### Étapes d'Installation

1. **Téléchargez la dernière version**
   - Rendez-vous sur la [page des releases](https://github.com/votre-username/DofusSwitcherWin/releases/latest)
   - Téléchargez le fichier `DofusSwitcherWin-v1.0.0.zip`

2. **Extrayez l'archive**
   - Faites un clic droit sur le fichier ZIP
   - Sélectionnez "Extraire tout..."
   - Choisissez un emplacement (ex: `C:\Program Files\DofusSwitcher`)

3. **Lancez l'application**
   - Double-cliquez sur `DofusSwitcherWin.exe`
   - Windows peut afficher un avertissement "Éditeur inconnu" → Cliquez sur "Plus d'infos" puis "Exécuter quand même"

4. **Première utilisation**
   - L'application se lance avec une interface vide
   - Ouvrez vos fenêtres Dofus
   - Cliquez sur le bouton "🔄 Rafraîchir" pour détecter vos fenêtres

> **Note :** Si WebView2 n'est pas installé, un message vous proposera de l'installer automatiquement.

---

## 🎯 Guide d'Utilisation

### Démarrage Rapide

1. **Lancez DofusSwitcher**
2. **Ouvrez vos clients Dofus**
3. **Cliquez sur "Rafraîchir"** pour détecter les fenêtres
4. **Configurez vos raccourcis** (optionnel)
5. **Commencez à jouer !**

### Configuration des Raccourcis

#### Raccourci Clavier
1. Cliquez sur le bouton "⌨️ Modifier" dans la sidebar
2. Une modale s'ouvre
3. Appuyez sur votre combinaison de touches (ex: Ctrl+Alt+D)
4. Le raccourci est enregistré automatiquement

#### Boutons Souris
1. Cliquez sur "🖱️ Suivant" ou "🖱️ Précédent"
2. Une modale s'ouvre
3. Cliquez sur le bouton X1 ou X2 de votre souris
4. Le bouton est configuré instantanément

> **Astuce :** Clic droit dans la modale pour effacer un bouton

### Organisation des Fenêtres

#### Ordre de Cycle
- Les **numéros bleus** sur chaque carte indiquent l'ordre de passage
- Utilisez les flèches **↑ ↓** pour réorganiser
- Désactivez une fenêtre avec le **toggle** pour la retirer du cycle

#### Sauvegarder une Configuration
1. Organisez vos fenêtres comme souhaité
2. Cliquez sur "💾 Sauvegarder config"
3. Entrez un nom (ex: "PvM Otomaï")
4. Votre configuration est sauvegardée

#### Charger une Configuration
- Cliquez sur une configuration dans la liste
- L'ordre des fenêtres est restauré automatiquement
- La configuration active est marquée avec une coche verte

---

## 🔧 Fonctionnalités Avancées

### Actions Rapides
- **Double-clic** sur une carte pour focus la fenêtre
- **Clic sur "Focus"** pour mettre au premier plan
- **Toggle** pour activer/désactiver temporairement

### Paramètres Système
- Les configurations sont sauvegardées dans `%APPDATA%/DofusSwitcherWin/settings.json`
- L'application se lance en fond avec une **icône dans la barre système**
- Réduction automatique dans la zone de notification

### Raccourcis Globaux
- Les raccourcis fonctionnent **même quand Dofus est au premier plan**
- Navigation transparente entre les fenêtres
- Pas de conflit avec les raccourcis Dofus

---

## 🔒 Sécurité et Confiance

### Scan Antivirus

DofusSwitcher a été scanné par **70 moteurs antivirus** via VirusTotal:

✅ **69/70 antivirus confirment que l'application est sûre**

- 🔗 [Voir le scan complet sur VirusTotal](https://www.virustotal.com/gui/file/0C1759BA22AE5523582F7739EE9412FC3FE6F480D53CA49167261B4210A19FA6)
- 📋 SHA256: `0C1759BA22AE5523582F7739EE9412FC3FE6F480D53CA49167261B4210A19FA6`

#### Faux Positif (Zillya)

Un seul antivirus (Zillya) signale un faux positif. **C'est normal et sans danger**:

- ✅ L'application est **100% sûre** et **open-source**
- ✅ 69 autres antivirus majeurs (Microsoft Defender, Kaspersky, Avast, etc.) confirment qu'elle est propre
- ⚠️ Les faux positifs arrivent car l'app utilise des hooks système pour gérer les fenêtres
- 📝 Le faux positif a été signalé à Zillya pour correction

### Pourquoi Windows Affiche un Avertissement?

**"Éditeur inconnu" / "Application non vérifiée"**

C'est normal pour les raisons suivantes:

1. **Pas de signature numérique**
   - Les certificats coûtent 200-400€/an
   - Peu d'apps gratuites/open-source sont signées

2. **Application nouvelle**
   - Windows SmartScreen n'a pas encore de "réputation"
   - Plus l'app est téléchargée, moins le warning apparaît

**Comment contourner le warning:**
1. Clic sur "Plus d'infos"
2. Clic sur "Exécuter quand même"
3. C'est tout ! ✅

### Code Open-Source

Le code source est **entièrement visible** sur GitHub:
- 📖 Vous pouvez vérifier exactement ce que fait l'application
- 🔍 Aucun code caché ou obfusqué
- 🤝 Les contributions sont les bienvenues

### Permissions Utilisées

DofusSwitcher utilise uniquement ces permissions Windows:

- 🪟 **Énumération des fenêtres** (pour détecter Dofus)
- ⌨️ **Hooks clavier globaux** (pour les raccourcis)
- 🖱️ **Hooks souris globaux** (pour les boutons X1/X2)
- 🎯 **Focus de fenêtres** (pour basculer entre les clients)

**Aucune connexion internet • Aucune collecte de données • Aucun keylogger**

---

## 🐛 Résolution de Problèmes

### Mes fenêtres ne sont pas détectées
- Assurez-vous que Dofus est bien lancé
- Cliquez sur "🔄 Rafraîchir"
- Vérifiez que les fenêtres Dofus ne sont pas minimisées dans la barre des tâches

### Le raccourci clavier ne fonctionne pas
- Certaines combinaisons sont réservées par Windows (ex: Alt+Tab)
- Essayez une autre combinaison
- L'application propose un fallback automatique (Ctrl+Alt+F13)

### Windows bloque l'application
- C'est normal, l'application n'est pas signée numériquement
- Cliquez sur "Plus d'infos" puis "Exécuter quand même"
- L'application est **100% safe** et open-source

### WebView2 ne s'installe pas
- Téléchargez manuellement : [WebView2 Runtime](https://go.microsoft.com/fwlink/p/?LinkId=2124703)
- Installez et relancez DofusSwitcher

### Les icônes des applications n'apparaissent pas
- C'est un comportement normal si l'icône n'est pas trouvée
- Un emoji 🎮 s'affiche par défaut
- Cela n'affecte pas le fonctionnement

---

## 🚀 Mises à Jour

### Vérifier les Mises à Jour
- Consultez la [page des releases](https://github.com/votre-username/DofusSwitcherWin/releases)
- Téléchargez la nouvelle version
- Remplacez l'ancien `.exe` par le nouveau

### Changelog v1.0.0 (Janvier 2025)
- 🎉 Version initiale
- ✨ Interface moderne avec Tailwind CSS
- ⌨️ Configuration des raccourcis clavier
- 🖱️ Configuration des boutons souris X1/X2
- 💾 Système de sauvegarde de configurations
- 🪟 Détection automatique des fenêtres
- 🎨 Extraction des icônes d'applications

---

## 📞 Support et Contact

### Besoin d'Aide ?
- Ouvrez une [issue sur GitHub](https://github.com/votre-username/DofusSwitcherWin/issues)
- Consultez les [discussions](https://github.com/votre-username/DofusSwitcherWin/discussions)
- Rejoignez notre [Discord](votre-lien-discord) (optionnel)

### Signaler un Bug
1. Vérifiez qu'il n'a pas déjà été signalé
2. Ouvrez une nouvelle issue
3. Décrivez le problème avec :
   - Version de Windows
   - Version de DofusSwitcher
   - Étapes pour reproduire
   - Captures d'écran si possible

### Proposer une Fonctionnalité
Les suggestions sont les bienvenues ! Ouvrez une issue avec le tag `enhancement`.

---

## 🤝 Contribution

Ce projet est **open-source** ! Les contributions sont les bienvenues :

- 🐛 Correction de bugs
- ✨ Nouvelles fonctionnalités
- 📝 Amélioration de la documentation
- 🌍 Traductions

Consultez le fichier `CONTRIBUTING.md` pour plus d'infos.

---

## 📄 Licence

Ce projet est distribué sous licence **MIT**. Voir le fichier `LICENSE` pour plus de détails.

Vous êtes libre de :
- ✅ Utiliser le logiciel à des fins personnelles ou commerciales
- ✅ Modifier le code source
- ✅ Distribuer des copies
- ✅ Créer des versions dérivées

---

## 🙏 Remerciements

- **Ankama** pour Dofus
- **La communauté Dofus** pour les retours et suggestions
- **Tailwind CSS** pour le framework UI
- **Microsoft WebView2** pour le moteur de rendu moderne

---

## ⚠️ Disclaimer

**DofusSwitcher** est un outil tiers non affilié à Ankama. Il ne modifie pas le client Dofus et respecte les règles du jeu. L'utilisation se fait à vos propres risques.

Le multi-compte est autorisé sur Dofus selon les règles d'Ankama. Cet outil facilite simplement la navigation entre fenêtres.

---

<div align="center">

**Fait avec ❤️ pour la communauté Dofus**

⭐ Si vous aimez ce projet, n'hésitez pas à lui donner une étoile sur GitHub !

[Télécharger](https://github.com/votre-username/DofusSwitcherWin/releases/latest) • [Signaler un bug](https://github.com/votre-username/DofusSwitcherWin/issues) • [Proposer une fonctionnalité](https://github.com/votre-username/DofusSwitcherWin/discussions)

</div>
